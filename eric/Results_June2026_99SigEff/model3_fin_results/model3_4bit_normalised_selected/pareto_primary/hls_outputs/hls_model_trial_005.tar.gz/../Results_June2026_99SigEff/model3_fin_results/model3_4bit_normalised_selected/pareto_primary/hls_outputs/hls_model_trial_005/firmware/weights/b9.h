//Numpy array shape [10]
//Min 0.000000000000
//Max 0.125000000000
//Number of zeros 8

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
bias9_t b9[10];
#else
bias9_t b9[10] = {0.125, 0.000, 0.125, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000};
#endif

#endif
