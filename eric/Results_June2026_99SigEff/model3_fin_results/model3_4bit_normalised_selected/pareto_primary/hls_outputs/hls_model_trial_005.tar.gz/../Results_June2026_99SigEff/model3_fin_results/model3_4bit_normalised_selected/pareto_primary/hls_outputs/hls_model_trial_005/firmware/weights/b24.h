//Numpy array shape [6]
//Min -0.250000000000
//Max 0.625000000000
//Number of zeros 0

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[6];
#else
bias24_t b24[6] = {0.625, -0.125, -0.125, -0.250, 0.500, 0.125};
#endif

#endif
