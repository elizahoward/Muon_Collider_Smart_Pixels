//Numpy array shape [16]
//Min -0.500000000000
//Max 0.375000000000
//Number of zeros 4

#ifndef B16_H_
#define B16_H_

#ifndef __SYNTHESIS__
bias16_t b16[16];
#else
bias16_t b16[16] = {0.125, -0.375, 0.125, 0.000, 0.000, 0.375, -0.500, -0.250, 0.000, 0.125, -0.375, -0.125, -0.125, 0.375, -0.125, 0.000};
#endif

#endif
