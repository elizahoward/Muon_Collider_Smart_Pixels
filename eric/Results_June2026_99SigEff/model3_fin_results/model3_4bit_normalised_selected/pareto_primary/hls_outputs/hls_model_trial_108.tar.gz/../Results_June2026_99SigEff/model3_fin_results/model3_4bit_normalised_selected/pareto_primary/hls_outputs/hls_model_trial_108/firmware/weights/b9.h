//Numpy array shape [2]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
bias9_t b9[2];
#else
bias9_t b9[2] = {0.000, 0.000};
#endif

#endif
