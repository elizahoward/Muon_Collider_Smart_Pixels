//Numpy array shape [3, 1]
//Min -0.875000000000
//Max -0.500000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[3];
#else
weight27_t w27[3] = {-0.625, -0.875, -0.500};
#endif

#endif
