//Numpy array shape [3]
//Min -0.125000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[3];
#else
bias24_t b24[3] = {-0.125, 0.000, 0.000};
#endif

#endif
