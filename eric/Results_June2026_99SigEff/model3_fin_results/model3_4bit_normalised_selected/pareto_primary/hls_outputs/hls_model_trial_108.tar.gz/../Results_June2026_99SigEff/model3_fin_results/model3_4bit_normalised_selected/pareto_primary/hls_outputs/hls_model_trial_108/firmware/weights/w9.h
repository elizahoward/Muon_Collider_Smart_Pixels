//Numpy array shape [3, 3, 1, 2]
//Min -0.375000000000
//Max 0.875000000000
//Number of zeros 0

#ifndef W9_H_
#define W9_H_

#ifndef __SYNTHESIS__
weight9_t w9[18];
#else
weight9_t w9[18] = {-0.125, -0.250, 0.375, 0.875, 0.875, 0.250, 0.375, 0.375, 0.125, 0.875, -0.375, -0.250, 0.875, 0.750, 0.875, 0.500, 0.500, -0.125};
#endif

#endif
