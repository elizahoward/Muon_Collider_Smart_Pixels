//Numpy array shape [12, 1]
//Min -1.000000000000
//Max 0.875000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[12];
#else
weight27_t w27[12] = {-1.000, 0.500, 0.750, -1.000, -1.000, -0.375, 0.125, -0.750, 0.875, 0.250, -1.000, -1.000};
#endif

#endif
