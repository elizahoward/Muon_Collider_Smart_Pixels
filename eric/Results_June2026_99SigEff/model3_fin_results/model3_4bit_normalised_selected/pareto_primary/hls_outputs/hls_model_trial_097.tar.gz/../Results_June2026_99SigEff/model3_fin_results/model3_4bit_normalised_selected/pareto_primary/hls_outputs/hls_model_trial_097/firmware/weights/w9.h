//Numpy array shape [3, 3, 1, 2]
//Min -1.000000000000
//Max 0.875000000000
//Number of zeros 0

#ifndef W9_H_
#define W9_H_

#ifndef __SYNTHESIS__
weight9_t w9[18];
#else
weight9_t w9[18] = {-0.625, 0.875, 0.125, 0.875, -0.375, 0.250, 0.125, 0.875, -0.250, -0.875, -1.000, -1.000, 0.125, 0.500, 0.375, 0.750, 0.500, 0.250};
#endif

#endif
