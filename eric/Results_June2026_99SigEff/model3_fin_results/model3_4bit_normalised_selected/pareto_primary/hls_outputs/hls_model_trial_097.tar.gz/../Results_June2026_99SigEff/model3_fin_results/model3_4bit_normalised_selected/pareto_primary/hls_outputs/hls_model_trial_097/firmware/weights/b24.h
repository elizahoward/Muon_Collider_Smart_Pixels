//Numpy array shape [12]
//Min -0.250000000000
//Max 0.375000000000
//Number of zeros 3

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[12];
#else
bias24_t b24[12] = {-0.125, 0.125, 0.375, -0.125, -0.250, -0.125, 0.000, 0.000, -0.250, 0.000, -0.125, -0.250};
#endif

#endif
