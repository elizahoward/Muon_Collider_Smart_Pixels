//Numpy array shape [5]
//Min -0.250000000000
//Max 0.875000000000
//Number of zeros 1

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[5];
#else
bias24_t b24[5] = {-0.125, 0.750, -0.250, 0.000, 0.875};
#endif

#endif
