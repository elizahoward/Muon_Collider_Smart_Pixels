//Numpy array shape [5, 1]
//Min -0.625000000000
//Max 0.625000000000
//Number of zeros 1

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[5];
#else
weight27_t w27[5] = {-0.625, 0.375, -0.250, 0.000, 0.625};
#endif

#endif
