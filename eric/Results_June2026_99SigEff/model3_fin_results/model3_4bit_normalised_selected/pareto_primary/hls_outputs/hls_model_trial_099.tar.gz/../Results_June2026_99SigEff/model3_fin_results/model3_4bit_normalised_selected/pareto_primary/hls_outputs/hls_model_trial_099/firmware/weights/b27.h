//Numpy array shape [1]
//Min -0.125000000000
//Max -0.125000000000
//Number of zeros 0

#ifndef B27_H_
#define B27_H_

#ifndef __SYNTHESIS__
bias27_t b27[1];
#else
bias27_t b27[1] = {-0.125};
#endif

#endif
