//Numpy array shape [8]
//Min -0.125000000000
//Max 0.500000000000
//Number of zeros 2

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[8];
#else
bias24_t b24[8] = {0.375, 0.000, -0.125, 0.500, 0.000, 0.250, 0.250, -0.125};
#endif

#endif
