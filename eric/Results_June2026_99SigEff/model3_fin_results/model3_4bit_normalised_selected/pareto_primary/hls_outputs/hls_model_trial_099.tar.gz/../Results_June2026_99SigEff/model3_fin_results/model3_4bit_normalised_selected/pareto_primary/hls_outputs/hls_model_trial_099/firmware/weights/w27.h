//Numpy array shape [8, 1]
//Min -0.625000000000
//Max 0.750000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[8];
#else
weight27_t w27[8] = {0.250, 0.375, -0.500, 0.625, -0.625, 0.750, 0.375, -0.375};
#endif

#endif
