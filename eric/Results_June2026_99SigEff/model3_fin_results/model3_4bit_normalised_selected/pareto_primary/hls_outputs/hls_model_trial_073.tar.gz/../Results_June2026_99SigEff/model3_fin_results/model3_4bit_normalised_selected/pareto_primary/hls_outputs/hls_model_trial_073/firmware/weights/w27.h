//Numpy array shape [17, 1]
//Min -1.000000000000
//Max 0.875000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[17];
#else
weight27_t w27[17] = {-0.250, -1.000, 0.375, 0.500, 0.250, 0.875, -0.375, 0.250, -0.250, 0.125, -0.750, -0.250, -0.750, -0.375, -0.125, 0.125, 0.125};
#endif

#endif
