//Numpy array shape [19, 1]
//Min -1.000000000000
//Max 0.750000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[19];
#else
weight27_t w27[19] = {-0.375, -0.500, -0.375, -0.500, 0.750, -0.375, -0.750, 0.250, -1.000, 0.375, 0.375, 0.500, -0.125, -0.375, -0.500, -0.125, 0.250, 0.125, -0.375};
#endif

#endif
