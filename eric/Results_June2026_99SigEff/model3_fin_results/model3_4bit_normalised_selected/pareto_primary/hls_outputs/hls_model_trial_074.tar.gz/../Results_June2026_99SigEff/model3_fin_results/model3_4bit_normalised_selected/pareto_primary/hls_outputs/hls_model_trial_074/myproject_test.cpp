#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include "firmware/myproject.h"
#include "firmware/nnet_utils/nnet_helpers.h"

// hls-fpga-machine-learning insert bram
#include "firmware/weights/w9.h"
#include "firmware/weights/b9.h"
#include "firmware/weights/w16.h"
#include "firmware/weights/b16.h"
#include "firmware/weights/w21.h"
#include "firmware/weights/b21.h"
#include "firmware/weights/w24.h"
#include "firmware/weights/b24.h"
#include "firmware/weights/w27.h"
#include "firmware/weights/b27.h"

#define CHECKPOINT 5000

namespace nnet {
bool trace_enabled = true;
std::map<std::string, void *> *trace_outputs = NULL;
size_t trace_type_size = sizeof(double);
} // namespace nnet

int main(int argc, char **argv) {
    // load input data from text file
    std::ifstream fin("tb_data/tb_input_features.dat");
    // load predictions from text file
    std::ifstream fpr("tb_data/tb_output_predictions.dat");

#ifdef RTL_SIM
    std::string RESULTS_LOG = "tb_data/rtl_cosim_results.log";
#else
    std::string RESULTS_LOG = "tb_data/csim_results.log";
#endif
    std::ofstream fout(RESULTS_LOG);

    std::string iline;
    std::string pline;
    int e = 0;

    if (fin.is_open() && fpr.is_open()) {
        while (std::getline(fin, iline) && std::getline(fpr, pline)) {
            if (e % CHECKPOINT == 0)
                std::cout << "Processing input " << e << std::endl;
            char *cstr = const_cast<char *>(iline.c_str());
            char *current;
            std::vector<float> in;
            current = strtok(cstr, " ");
            while (current != NULL) {
                in.push_back(atof(current));
                current = strtok(NULL, " ");
            }
            cstr = const_cast<char *>(pline.c_str());
            std::vector<float> pr;
            current = strtok(cstr, " ");
            while (current != NULL) {
                pr.push_back(atof(current));
                current = strtok(NULL, " ");
            }

            // hls-fpga-machine-learning insert data
      input_t cluster[N_INPUT_1_1*N_INPUT_2_1];
      nnet::copy_data<float, input_t, 0, N_INPUT_1_1*N_INPUT_2_1>(in, cluster);
      input3_t nModule[N_INPUT_1_3];
      nnet::copy_data<float, input3_t, 273, N_INPUT_1_3>(in, nModule);
      input4_t x_local[N_INPUT_1_4];
      nnet::copy_data<float, input4_t, 274, N_INPUT_1_4>(in, x_local);
      input8_t y_local[N_INPUT_1_8];
      nnet::copy_data<float, input8_t, 275, N_INPUT_1_8>(in, y_local);
      result_t layer29_out[N_LAYER_27];

            // hls-fpga-machine-learning insert top-level-function
            myproject(cluster,nModule,x_local,y_local,layer29_out,w9,b9,w16,b16,w21,b21,w24,b24,w27,b27);

            if (e % CHECKPOINT == 0) {
                std::cout << "Predictions" << std::endl;
                // hls-fpga-machine-learning insert predictions
                for(int i = 0; i < N_LAYER_27; i++) {
                  std::cout << pr[i] << " ";
                }
                std::cout << std::endl;
                std::cout << "Quantized predictions" << std::endl;
                // hls-fpga-machine-learning insert quantized
                nnet::print_result<result_t, N_LAYER_27>(layer29_out, std::cout, true);
            }
            e++;

            // hls-fpga-machine-learning insert tb-output
            nnet::print_result<result_t, N_LAYER_27>(layer29_out, fout);
        }
        fin.close();
        fpr.close();
    } else {
        std::cout << "INFO: Unable to open input/predictions file, using default input." << std::endl;

        // hls-fpga-machine-learning insert zero
    input_t cluster[N_INPUT_1_1*N_INPUT_2_1];
    nnet::fill_zero<input_t, N_INPUT_1_1*N_INPUT_2_1>(cluster);
    input3_t nModule[N_INPUT_1_3];
    nnet::fill_zero<input3_t, N_INPUT_1_3>(nModule);
    input4_t x_local[N_INPUT_1_4];
    nnet::fill_zero<input4_t, N_INPUT_1_4>(x_local);
    input8_t y_local[N_INPUT_1_8];
    nnet::fill_zero<input8_t, N_INPUT_1_8>(y_local);
    result_t layer29_out[N_LAYER_27];

        // hls-fpga-machine-learning insert top-level-function
        myproject(cluster,nModule,x_local,y_local,layer29_out,w9,b9,w16,b16,w21,b21,w24,b24,w27,b27);

        // hls-fpga-machine-learning insert output
        nnet::print_result<result_t, N_LAYER_27>(layer29_out, std::cout, true);

        // hls-fpga-machine-learning insert tb-output
        nnet::print_result<result_t, N_LAYER_27>(layer29_out, fout);
    }

    fout.close();
    std::cout << "INFO: Saved inference results to file: " << RESULTS_LOG << std::endl;

    return 0;
}
