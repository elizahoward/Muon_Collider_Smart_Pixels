//Numpy array shape [6]
//Min -0.125000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
bias9_t b9[6];
#else
bias9_t b9[6] = {0.000, 0.000, -0.125, 0.000, 0.000, -0.125};
#endif

#endif
