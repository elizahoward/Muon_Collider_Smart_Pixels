//Numpy array shape [18, 1]
//Min -0.750000000000
//Max 0.750000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[18];
#else
weight27_t w27[18] = {0.250, -0.125, -0.750, -0.500, -0.625, 0.250, 0.750, 0.125, -0.500, -0.750, 0.375, -0.375, 0.500, 0.125, -0.500, -0.375, -0.250, 0.250};
#endif

#endif
