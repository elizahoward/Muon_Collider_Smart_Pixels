//Numpy array shape [18]
//Min -0.500000000000
//Max 0.500000000000
//Number of zeros 1

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[18];
#else
bias24_t b24[18] = {0.250, -0.250, -0.250, 0.125, -0.500, -0.250, 0.500, 0.250, -0.125, -0.125, -0.375, -0.250, -0.125, 0.375, -0.250, -0.125, -0.250, 0.000};
#endif

#endif
