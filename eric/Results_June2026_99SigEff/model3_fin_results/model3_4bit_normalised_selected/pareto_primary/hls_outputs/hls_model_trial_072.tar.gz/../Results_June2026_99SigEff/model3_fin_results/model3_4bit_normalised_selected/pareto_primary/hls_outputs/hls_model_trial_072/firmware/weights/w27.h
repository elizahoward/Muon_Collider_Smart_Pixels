//Numpy array shape [5, 1]
//Min -1.000000000000
//Max 0.875000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[5];
#else
weight27_t w27[5] = {-0.625, 0.875, -1.000, -1.000, -0.500};
#endif

#endif
