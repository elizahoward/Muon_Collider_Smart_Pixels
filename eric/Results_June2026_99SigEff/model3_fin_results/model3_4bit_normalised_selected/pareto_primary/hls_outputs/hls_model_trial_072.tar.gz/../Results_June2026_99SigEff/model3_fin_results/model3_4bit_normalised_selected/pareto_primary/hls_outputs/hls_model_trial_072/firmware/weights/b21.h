//Numpy array shape [8]
//Min -0.125000000000
//Max 0.125000000000
//Number of zeros 4

#ifndef B21_H_
#define B21_H_

#ifndef __SYNTHESIS__
bias21_t b21[8];
#else
bias21_t b21[8] = {0.000, 0.000, 0.125, -0.125, 0.125, 0.000, 0.000, -0.125};
#endif

#endif
