//Numpy array shape [8]
//Min -0.250000000000
//Max 0.625000000000
//Number of zeros 3

#ifndef B16_H_
#define B16_H_

#ifndef __SYNTHESIS__
bias16_t b16[8];
#else
bias16_t b16[8] = {0.000, 0.125, 0.625, -0.250, 0.000, 0.000, 0.250, -0.250};
#endif

#endif
