//Numpy array shape [5]
//Min -0.750000000000
//Max 0.500000000000
//Number of zeros 0

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[5];
#else
bias24_t b24[5] = {0.125, 0.375, 0.500, -0.750, 0.250};
#endif

#endif
