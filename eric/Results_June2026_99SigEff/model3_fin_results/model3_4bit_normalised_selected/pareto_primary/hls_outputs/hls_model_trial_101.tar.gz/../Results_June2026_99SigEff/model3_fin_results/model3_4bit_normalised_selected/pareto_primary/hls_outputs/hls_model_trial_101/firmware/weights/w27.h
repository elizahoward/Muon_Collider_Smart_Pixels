//Numpy array shape [11, 1]
//Min -1.000000000000
//Max 0.750000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[11];
#else
weight27_t w27[11] = {-0.250, -1.000, -0.375, -0.250, 0.750, -0.875, 0.250, 0.250, -0.625, -0.750, -0.750};
#endif

#endif
