//Numpy array shape [11]
//Min -0.250000000000
//Max 0.625000000000
//Number of zeros 1

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[11];
#else
bias24_t b24[11] = {-0.250, -0.250, -0.125, 0.000, 0.625, -0.250, -0.125, 0.500, -0.250, -0.125, -0.125};
#endif

#endif
