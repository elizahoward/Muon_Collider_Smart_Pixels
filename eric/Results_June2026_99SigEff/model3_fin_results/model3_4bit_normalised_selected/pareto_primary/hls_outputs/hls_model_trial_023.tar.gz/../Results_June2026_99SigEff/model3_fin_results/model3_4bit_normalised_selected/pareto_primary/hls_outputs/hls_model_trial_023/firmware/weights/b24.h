//Numpy array shape [4]
//Min 0.000000000000
//Max 0.625000000000
//Number of zeros 2

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[4];
#else
bias24_t b24[4] = {0.000, 0.625, 0.000, 0.625};
#endif

#endif
