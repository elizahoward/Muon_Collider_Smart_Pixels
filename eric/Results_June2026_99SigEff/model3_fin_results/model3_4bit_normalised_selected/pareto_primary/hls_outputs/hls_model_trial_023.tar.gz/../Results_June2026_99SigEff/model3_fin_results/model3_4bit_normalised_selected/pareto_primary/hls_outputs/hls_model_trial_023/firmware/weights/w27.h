//Numpy array shape [4, 1]
//Min -1.000000000000
//Max 0.750000000000
//Number of zeros 0

#ifndef W27_H_
#define W27_H_

#ifndef __SYNTHESIS__
weight27_t w27[4];
#else
weight27_t w27[4] = {-1.000, 0.750, -0.875, 0.625};
#endif

#endif
