//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef B21_H_
#define B21_H_

#ifndef __SYNTHESIS__
bias21_t b21[1];
#else
bias21_t b21[1] = {0.000};
#endif

#endif
