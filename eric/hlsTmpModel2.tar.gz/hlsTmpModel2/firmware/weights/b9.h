//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
bias9_t b9[8];
#else
bias9_t b9[8] = {0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00};
#endif

#endif
