//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
bias23_t b23[1];
#else
bias23_t b23[1] = {0.00000};
#endif

#endif
