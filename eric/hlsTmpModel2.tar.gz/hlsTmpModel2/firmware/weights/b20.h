//Numpy array shape [16]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 16

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
bias20_t b20[16];
#else
bias20_t b20[16] = {0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00};
#endif

#endif
