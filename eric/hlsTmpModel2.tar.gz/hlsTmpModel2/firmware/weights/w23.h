//Numpy array shape [16, 1]
//Min -0.750000000000
//Max 0.750000000000
//Number of zeros 3

#ifndef W23_H_
#define W23_H_

#ifndef __SYNTHESIS__
weight23_t w23[16];
#else
weight23_t w23[16] = {0.25, 0.25, -0.25, -0.75, 0.00, -0.25, 0.25, 0.75, 0.00, 0.50, 0.50, -0.50, -0.50, 0.50, 0.00, -0.25};
#endif

#endif
