//Numpy array shape [4, 1]
//Min -0.625000000000
//Max 0.875000000000
//Number of zeros 0

#ifndef W22_H_
#define W22_H_

#ifndef __SYNTHESIS__
weight22_t w22[4];
#else
weight22_t w22[4] = {-0.625, -0.500, 0.875, 0.875};
#endif

#endif
