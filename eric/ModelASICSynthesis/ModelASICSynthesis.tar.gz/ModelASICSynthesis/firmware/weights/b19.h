//Numpy array shape [4]
//Min -0.375000000000
//Max 0.500000000000
//Number of zeros 2

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
bias19_t b19[4];
#else
bias19_t b19[4] = {0.000, 0.000, -0.375, 0.500};
#endif

#endif
