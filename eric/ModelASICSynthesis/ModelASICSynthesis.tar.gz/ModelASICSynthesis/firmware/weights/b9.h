//Numpy array shape [8]
//Min -1.000000000000
//Max 0.500000000000
//Number of zeros 2

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
bias9_t b9[8];
#else
bias9_t b9[8] = {-0.125, -1.000, 0.000, 0.000, 0.500, 0.250, -0.125, -0.875};
#endif

#endif
