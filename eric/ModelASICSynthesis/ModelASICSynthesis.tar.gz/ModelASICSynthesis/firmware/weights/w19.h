//Numpy array shape [4, 4]
//Min -1.000000000000
//Max 0.875000000000
//Number of zeros 1

#ifndef W19_H_
#define W19_H_

#ifndef __SYNTHESIS__
weight19_t w19[16];
#else
weight19_t w19[16] = {-0.250, 0.000, 0.875, -1.000, 0.875, -0.250, -1.000, -0.375, 0.625, 0.875, -0.125, -0.375, 0.875, -1.000, -0.375, -0.375};
#endif

#endif
