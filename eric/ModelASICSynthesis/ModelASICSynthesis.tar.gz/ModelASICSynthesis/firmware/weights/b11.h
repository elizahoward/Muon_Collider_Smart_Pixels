//Numpy array shape [2]
//Min 0.000000000000
//Max 0.968750000000
//Number of zeros 1

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[2];
#else
bias11_t b11[2] = {0.96875, 0.00000};
#endif

#endif
