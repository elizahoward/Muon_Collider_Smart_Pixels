//Numpy array shape [9]
//Min -0.243147626519
//Max 0.502243697643
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
dense_3_bias_t b8[9];
#else
dense_3_bias_t b8[9] = {0.2357424349, -0.0641634017, -0.1365035623, 0.1259463131, -0.0247112624, 0.5022436976, -0.2431476265, 0.2654477954, 0.2812648416};
#endif

#endif
