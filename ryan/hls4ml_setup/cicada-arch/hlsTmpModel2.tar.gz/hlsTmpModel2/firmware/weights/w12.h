//Numpy array shape [9, 1]
//Min -5.155309677124
//Max 5.589313983917
//Number of zeros 0

#ifndef W12_H_
#define W12_H_

#ifndef __SYNTHESIS__
dense_5_weight_t w12[9];
#else
dense_5_weight_t w12[9] = {5.5893139839, -1.9805282354, -1.9861857891, -5.1553096771, -2.1285204887, -1.4032585621, -2.5788161755, 4.3458280563, 4.0643720627};
#endif

#endif
