//Numpy array shape [9]
//Min -0.429917931557
//Max 0.830479681492
//Number of zeros 0

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
dense_4_bias_t b10[9];
#else
dense_4_bias_t b10[9] = {-0.2846430540, 0.3061860800, 0.2400924265, -0.4299179316, 0.2181357890, -0.0375183374, -0.2182844728, 0.7240121961, 0.8304796815};
#endif

#endif
