//Numpy array shape [1]
//Min 0.300240218639
//Max 0.300240218639
//Number of zeros 0

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
dense_5_bias_t b12[1];
#else
dense_5_bias_t b12[1] = {0.3002402186};
#endif

#endif
